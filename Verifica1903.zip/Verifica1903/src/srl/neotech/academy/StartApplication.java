package srl.neotech.academy;

import java.util.Scanner;

public class StartApplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//aggiungi velocita
		Astronave astronave=new Astronave();
		
		Scanner scanVelocita=new Scanner(System.in);
		System.out.println("A quale velocita si vuole decollare?");
		Integer s=scanVelocita.nextInt();
		
		
		Scanner scanManovre=new Scanner(System.in);
		

	}

}
