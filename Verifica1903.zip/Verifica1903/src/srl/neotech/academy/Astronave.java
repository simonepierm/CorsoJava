package srl.neotech.academy;

public class Astronave implements IAstronave {
	
	private Integer velocita; 
	
	@Override
	public String decolla() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String accellera() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String decellera() {
		// TODO Auto-generated method stub
		return null;
	}

	
	

}
