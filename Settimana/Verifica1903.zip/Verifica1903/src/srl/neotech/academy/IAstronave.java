package srl.neotech.academy;

public interface IAstronave {

	public String decolla();
	public String accellera();
	public String decellera();
	
	
	
	
	
	
}
